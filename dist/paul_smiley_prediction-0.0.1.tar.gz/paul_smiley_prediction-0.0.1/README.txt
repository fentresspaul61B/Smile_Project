This is a library which contains a pre-trained model to predict
hand-drawn smiley faces (Happy, Sad).

You can use this library with Streamlit for example,
to collect hand-drawn smiley faces and predict them.
